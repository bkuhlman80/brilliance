# Handoff: ship the Explorer (Ancestor / Bramble panel toggle)

Target repo: **bkuhlman80/abhop-explorer** (branch `main`). All paths under `trellis-site/`.

## What ships
1. **`trellis-site/Bramble Explorer.dc.html`** — the Explorer, adding the desktop far-right panel's **View toggle**:
   - **Ancestor** — the existing panel, unchanged (clade specimen w/ REC dot, or venn-flower term explanations).
   - **Bramble** — new Unit 03 view, built to `bramble_specs_v1_4.md`:
     - **Identity plate** — UNIT 03 · clade, chassis line (vacuum / tetrapod / humanoid), hand-labeled "Bramble" price-dot sticker, build description.
     - **Face-screen** — the involuntary readout, one layer per clade (movement / carry / arousal panels → OBJECT → VERB+OBJECT → =OUTCOME → PERSON columns). Gated on the clade's NEW knob: down = the layer eclipses and the screen falls through to the layer beneath (status reads ○ Dark). City-Human+ gains the voluntary ASCII channel (Readout | ASCII toggle).
     - **Installed systems** — the four functions at their current knob generation; NEW vs HELD chips; retired-to-firmware line (e.g. "Risking replaces Getting (March / Dance)…").
     - **Disposition knobs** — four two-pole volume knobs (up = derived/expressive, down = primordial/suppressive), wearing Mira's sticker names. Click toggles the knob, drives the face-screen, and opens its readout (proper name, motivation, board label, Lab + Mira poles, up/down behavior, face-effect note).
   - Desktop only; mobile Bramble view is a follow-up.
2. **`trellis-site/bramble-data.js`** *(new, Code-owned)* — ALL Bramble-view words: the 12 knobs (poles, Mira names, up/down copy), per-clade builds + face readouts, and the view's chrome strings. Face readout examples (CHASE CAT etc.) are design drafts — edit freely here; the Explorer re-renders live. Loaded via `<script src="bramble-data.js">` in the helmet.
3. **`trellis-site/ui-copy.js`** *(Code-owned)* — all pre-existing chrome strings; include if the previous handoff hasn't landed yet.

## Commit & push (Claude Code, from repo root with this bundle copied in)
```bash
git add trellis-site/Bramble\ Explorer.dc.html \
        trellis-site/bramble-data.js \
        trellis-site/ui-copy.js
git commit -m "feat(explorer): Ancestor/Bramble panel toggle — Unit 03 face-screen, systems spec, disposition knobs"
git push origin main
```
Cloudflare Pages rebuilds from source on push (`node build.mjs` → `dist/`). Local preview:
```bash
cd trellis-site && node build.mjs && npx serve dist
```
